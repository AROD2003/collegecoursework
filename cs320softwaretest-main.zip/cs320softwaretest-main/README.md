# cs320softwaretest
How can I ensure that my code, program, or software is functional and secure?
Make sure you do thorough testing, and perform code reviews regularly. Follow secure coding guidelines, validate user input, and keep any dependencies up-to-date. 

How do I interpret user needs and incorporate them into a program?
Use interviews, reviews, surveys, and usability tests to understasnd user requirements. Prioritize them and go through different testing and prototypes to introduce features.

How do I approach designing software?
I choose a well known and tested methodology and define a clear goal, and the tools used. Planning is the biggest and most important thing.
